package capgemini;
 class MyClass1 extends Thread {
    public void run(){
    System.out.println("MyClass running");
  }
}

public class ThreadDemo {

	public static void main(String[] args) {
		
		MyClass1 t1 = new MyClass1 ();
		t1.start();
	}

}
