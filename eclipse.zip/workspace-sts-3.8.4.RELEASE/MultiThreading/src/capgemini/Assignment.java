package capgemini;
class MyThread extends Thread
{
	public void run()
	{
		System.out.println("child thread");
	}
}
public class Assignment {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyThread m=new MyThread();
		m.start();

	}

}
