package capgemini;
class MyClass implements Runnable
{
	@Override
	public void run()
	{
		System.out.println("child thread"+Thread.currentThread().getName());
	}
}

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           MyClass m=new MyClass();
              Thread childThread=new Thread(m,"capgemini");
              childThread.start();
	}

}
