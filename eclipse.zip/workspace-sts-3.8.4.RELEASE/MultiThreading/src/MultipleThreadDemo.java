class MyThread extends Thread
{
	public void run()
	{  
		System.out.println("child thread");
	}
}
public class MultipleThreadDemo 
{
 public static void main(String[] args) {

System.out.println("main thread");
    MyThread m=new MyThread();
    		m.start();
    		try {
				m.join();
			} catch (InterruptedException e) {
				
				e.printStackTrace();
			}
    		System.out.println("last line of main thread");
	}

}
