
public class Producer implements Runnable {
	Warehouse warehouse;
	
	public Producer(Warehouse warehouse) {
		super();
		this.warehouse = warehouse;
	}

	@Override
	public void run() {
		while(true)
		{
			int num=(int)(Math.random()*100);
			warehouse.addItem(num);
			try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
