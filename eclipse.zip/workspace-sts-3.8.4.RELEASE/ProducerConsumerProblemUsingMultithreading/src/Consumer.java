
public class Consumer implements Runnable {
	Warehouse warehouse;
	
	public Consumer(Warehouse warehouse) {
		super();
		this.warehouse = warehouse;
	}
	@Override
	public void run() {
		 while(true)
		 {
			 warehouse.removeItem();
			 try {
				Thread.sleep(500);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 }

	}

}
