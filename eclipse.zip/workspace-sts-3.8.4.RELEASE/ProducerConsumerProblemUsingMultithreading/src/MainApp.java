
public class MainApp {
	public static void main(String[] args)
	{
		
	  Warehouse warehouse=new Warehouse();
	  Producer producer=new Producer(warehouse);
	  
	  Consumer consumer=new Consumer(warehouse);
	
	  Thread producerThread=new Thread(producer);
	  producerThread.start();
	  
	  Thread consumerThread=new Thread(consumer);
	  consumerThread.start();
	}
}