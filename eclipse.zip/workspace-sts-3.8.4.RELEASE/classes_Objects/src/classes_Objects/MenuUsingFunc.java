package classes_Objects;
class add(int a,int b)
{
	int c;
	c=a+b;
}

public class MenuUsingFunc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
