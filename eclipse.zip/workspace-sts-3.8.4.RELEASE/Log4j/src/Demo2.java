import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

public class Demo2{
	
	final static Logger logger = Logger.getLogger(Demo2.class);
	
	public static void main(String[] args) {
	
		Demo2 obj = new Demo2();
		obj.runMe("mkyong");
		
	}
	
	private void runMe(String parameter){
        BasicConfigurator.configure();

		if(logger.isDebugEnabled()){
			logger.debug("This is debug : " + parameter);
		}
		
		if(logger.isInfoEnabled()){
			logger.info("This is info : " + parameter);
		}
		
		logger.warn("This is warn : " + parameter);
		logger.error("This is error : " + parameter);
		logger.fatal("This is fatal : " + parameter);
		
	}
	
}