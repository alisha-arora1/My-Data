package yay;

import java.util.HashSet;

public class LinkedHashSetDemo {

	public static void main(String[] args) {
		HashSet h=new HashSet();
		   h.add(1);
		  
		   h.add(1);   //unique elements will be printed
		   h.add("alisha");
		   h.add("aaaa");

		   h.add(null);// single null will be printed
		   h.add(null);
		  

		   
		   System.out.println(h);

	}

}
