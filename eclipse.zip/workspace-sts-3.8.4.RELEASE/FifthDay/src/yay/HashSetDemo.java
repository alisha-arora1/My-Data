package yay;

import java.util.HashSet;

public class HashSetDemo {

	public static void main(String[] args) {
	   HashSet h=new HashSet();
	   h.add(1);
	  
	   h.add(1);   //unique elements will be printed
	   h.add("alisha");
	   h.add("aaaa");

	   h.add(null);// single null will be printed
	   h.add(null);
	  

	   //1
	   System.out.println(h);

	 /*  
	   //2
	   System.out.println("using index position");
	   for(int i;i<h.size();i++)
	   { 
		   System.out.println("");
		   
	   }
	   
	   
	   //3
	   System.out.println("");
	   
	   
	   //4
	   System.out.println("using iterator");
	   Iterator it=h.iterator();
	   while(it.hasNext())
	   {
		   System.out.println(it.next());
	   }
	   
	   
	   //5
	   
	   System.out.println("using list iterator");
	   ListIterator listit=h.ListIterator();
	   
	   while(listit.hasNext())
	   {
		   
	   }*/
	}

}
