    import java.io.IOException;
    import java.io.FileWriter;
    import java.io.BufferedWriter;
    import java.io.FileReader;
    import java.io.BufferedReader;
    public class BufferedReaderExample2 {
        public static void main(String[] args) {
            try
            {
               
                FileWriter fw = new
                        FileWriter("C:\\my\\alisha.txt");
                BufferedWriter WriteFileBuffer = new
                        BufferedWriter(fw);
     
                WriteFileBuffer.write("Alisha Arora");
                WriteFileBuffer.newLine();
                WriteFileBuffer.write("From");
                WriteFileBuffer.newLine();
                WriteFileBuffer.write("Capgemini India"+ "");
                WriteFileBuffer.newLine();
     
                WriteFileBuffer.close();
                FileReader fr = new FileReader("C:\\my\\alisha.txt");
                BufferedReader ReadFileBuffer = new BufferedReader(fr);
                System.out.println(ReadFileBuffer.readLine());
                System.out.println(ReadFileBuffer.readLine());
                System.out.println(ReadFileBuffer.readLine());
               
                ReadFileBuffer.close();
     
            } catch (IOException Ex)
            {
                System.out.println(Ex.getMessage());
            }
        }
    }