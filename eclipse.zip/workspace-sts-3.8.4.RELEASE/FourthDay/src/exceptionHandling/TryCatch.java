package exceptionHandling;

public class TryCatch {

	public static void main(String[] args) {
		try{
            String str=null;
          System.out.println(str.charAt(0));
		}catch(NullPointerException e)
		{   
			System.out.println("catch block");
			System.out.println("value is null");
		}
		finally{
			System.out.println("finally block");
		}

	}
}

