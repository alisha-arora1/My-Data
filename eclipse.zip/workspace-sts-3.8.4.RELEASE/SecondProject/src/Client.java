import java.util.Scanner;

public class Client {
	
	private static ICICIBank bank = new ICICIBank();
	private static Scanner sc=new Scanner(System.in);
	
	public static void main(String[] args) {
		
		showMenu();
	}
	private static void showMenu()
	{
		int choice;
		while(true)
		{
			
	    	System.out.println("menu:");
	    	System.out.println("1.Create Account");
	    	System.out.println("2.Deposit Amount");

	    	System.out.println("3.Withdraw Account");

	    	System.out.println("4.Fund Transfer");
	    	System.out.println("Enter your choice:");
	    	choice=sc.nextInt();
	    	switch(choice)
	    	{
	    	case 1:accountCreation();
	    	       break;
	    	       
	    	default: System.out.println("wrong choice");
	    	}

		}
	}
	private static void accountCreation()
	{
		System.out.println("Enter account number");
		int accountNumber=sc.nextInt();
		System.out.println("Enter amount");
		int amount=sc.nextInt();
		System.out.println(bank.createAccount(accountNumber,amount));
		
	}
		
		
		/*System.out.println(bank.createAccount(101, 3000));
		System.out.println(bank.createAccount(102, 3000));
		
		try
		{
			System.out.println("Balance = "+bank.withdrawAmount(101, 2000));
		}catch(InvalidAccountNumberException i)
		{
			System.out.println("Invalid account number ");
		}
		catch(InsufficientBalanceException ibe){
			System.out.println("insufficient balance");
		}*/

	

}

