package Account;

public class Account {
    
    private int accountNumber;
    private int amount;
    public Account(int accountNumber, int amount) {
        super();
        this.accountNumber = accountNumber;
        this.amount = amount;
    }
    public Account() {
        // TODO Auto-generated constructor stub
    }
    public Account(int i) {
        // TODO Auto-generated constructor stub
    }
    public int getAccountNumber() {
        return accountNumber;
    }
    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }
    public int getAmount() {
        return amount;
    }
    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    

}