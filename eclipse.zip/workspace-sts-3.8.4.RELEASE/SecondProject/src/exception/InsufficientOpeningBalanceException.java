package exception;

public class InsufficientOpeningBalanceException extends Exception {

}
