package exception;

public class InsufficientBalanceException extends Exception {

}