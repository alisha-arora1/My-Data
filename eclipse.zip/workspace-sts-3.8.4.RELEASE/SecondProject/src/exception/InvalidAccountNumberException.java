package exception;

public class InvalidAccountNumberException extends Exception {

}
