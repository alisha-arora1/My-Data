
class Employee
	{
		public Employee(String name)
		{
			System.out.println(name);
		}
	}

public class ConstructorDemo {
	

	public static void main(String[] args) {
		
		Employee emp = new Employee("alisha");
		Employee emp2 = new Employee("hanisha");

	}

}
