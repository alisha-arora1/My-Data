import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
public class FileWriterExample {
	public static void main(String[] args) {
		String name = "Alisha Arora";
		int age = 22;
		double temp = 22.9;
		FileWriter fw;
		try {
			fw = new FileWriter(new File("C:\\my\\alisha1.txt"));
			
			fw.write(String.format("My name is %s.",name));
			fw.write(System.lineSeparator()); //new line
			fw.write(String.format("I am %d years old.",age));
			fw.write(System.lineSeparator()); //new line
			fw.write(String.format("Today's temperature is %.2f.",temp));
			fw.write(System.lineSeparator()); //new line
			fw.close();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
		
		System.out.println("Done");
		
	}

}