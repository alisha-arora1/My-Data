

import java.io.File;
import java.io.FileReader;
public class FileReaderReadExample {

	public static void main(String[] args) {
		File file = null;
		FileReader reader = null;
		try {
			file = new File("C:/my/alishaarora.txt");
			reader = new FileReader(file);
			int i;
			while ((i=reader.read())!= -1) {
				System.out.print((char)i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				if (reader != null) {
					reader.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}
