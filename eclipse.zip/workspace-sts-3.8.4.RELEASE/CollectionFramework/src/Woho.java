import java.util.*;
public class Woho {
private String s;
public Woho(String s) { this.s = s; }
public static void main(String[] args) {
HashSet<Object> hs = new HashSet<Object>();
Woho ws1 = new Woho("aardvark�);
Woho ws2 = new Woho("aardvark�);
String s1 = new String("aardvark�);
String s2 = new String("aardvark�);
hs.add(ws1); hs.add(ws2); hs.add(s1); hs.add(s2);
System.out.println(hs.size()); } }
