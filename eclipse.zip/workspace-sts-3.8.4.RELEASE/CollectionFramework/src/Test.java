import java.util.Collections;
import java.util.LinkedList;
class Employee implements Comparable<Employee>
{
	private String name;
	public Employee(String name)
	{
		super();
		this.name=name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public int compareTo(Employee o) {
		System.out.println(name.compareTo(o.getName()));
		return name.compareTo(o.getName());
	}
}

public class Test {

	public static void main(String[] args) {
		LinkedList<Employee> list=new LinkedList<>();
		list.add(new Employee("Sachin"));
		list.add(new Employee("Ram"));
		
		Collections.sort(list);
		System.out.println(list);
		
		
	}

}
