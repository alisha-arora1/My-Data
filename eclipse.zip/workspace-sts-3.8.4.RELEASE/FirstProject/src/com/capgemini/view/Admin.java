
package com.capgemini.view;

import java.util.Scanner;

import com.capgemini.service.StudentSchedular;

public class Admin {

	private static Scanner sc=new Scanner(System.in);

	private static StudentSchedular studSch = new StudentSchedular();

	public static void main(String[] args) {

		showMenu();

	}

    private static void showMenu() {
         
		int choice;

		while(true)

		{

			System.out.println("1.add student");

			System.out.println("2.show all student's complete detail");
			System.out.println("3.Show Student by roll number");
			System.out.println("4.Show Student by course");
            System.out.println("5.exit");
			

			System.out.println("Enter your choice:");

			choice=sc.nextInt();

			switch(choice)

			{

			case 1: addStudentDetails();
                    break;

			 case 2:showAllStudents();

			        break;
			 case 3: showByRollNo();
			        
			         break;
			 case 4: showByCourse();
			         break;
			 
			 case 5:System.exit(0);

			 default:System.out.println("Sorry entered wrong choice");

		    }

          }
        }

   
 private static void showByCourse() {
		
	System.out.println("enter the course");
	String courseName=sc.next();
		   studSch.showByCourse(courseName);
	}

private static void showByRollNo() {
	System.out.println("enter the roll number:");
	int rno=sc.nextInt();
		   studSch.showByRollNo(rno);
		
	}

private static void showAllStudents() {

		studSch.showAllStudents();

		}
	private static void addStudentDetails() {

		System.out.println("Enter roll number");

		int rollNumber=sc.nextInt();
		 if(!studSch.isRollNumberPresent(rollNumber))
		 {
			 
			 
	    	System.out.println("Enter name");
            String name = sc.next();
		    System.out.println("Enter number of courses");
	     	int noOfCourses=sc.nextInt();
		    System.out.println("Enter courses");

		    String[] courses=new String[noOfCourses];
		
		
		     for(int i=0;i<noOfCourses;i++)
		     {
			   courses[i]=sc.next();
		     }

		    System.out.println(studSch.addStudent(rollNumber, name,noOfCourses,courses));
		 }
		 else
			 System.out.println("roll number already exists");
		

	}

}
