package InheritanceExample;
class A
{
	int no;
	String name;
	A(int no,String name)
	{
		this.no=no;
		this.name=name;
		
	}
	A()
	{
		this(5,"alisha");
	}
	
	
}
class B extends A
{
	B()
	{
	super(5,"hani");
	
	}
	
}
