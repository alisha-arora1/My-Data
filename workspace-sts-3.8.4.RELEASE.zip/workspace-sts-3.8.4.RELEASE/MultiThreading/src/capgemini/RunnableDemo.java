package capgemini;
class One1 implements Runnable
{
	public void run(){
		System.out.println("yayy");
	}
}

public class RunnableDemo {

	public static void main(String[] args) {
		
     One1 o=new One1();
     Thread childThread1=new Thread(o)
    		 ;
     childThread1.start();
     Thread childThread2=new Thread(o);
     childThread2.start();
	}

}
