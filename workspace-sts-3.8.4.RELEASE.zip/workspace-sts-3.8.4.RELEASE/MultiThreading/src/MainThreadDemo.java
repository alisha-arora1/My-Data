
public class MainThreadDemo {

	public static void main(String[] args) {
		System.out.println(Thread);

	}

}
