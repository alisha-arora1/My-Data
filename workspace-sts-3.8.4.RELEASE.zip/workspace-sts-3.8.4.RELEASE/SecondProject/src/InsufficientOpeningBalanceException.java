
public class InsufficientOpeningBalanceException extends Exception {

}
