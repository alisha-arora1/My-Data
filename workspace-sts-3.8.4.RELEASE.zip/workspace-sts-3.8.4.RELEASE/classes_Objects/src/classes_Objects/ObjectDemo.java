package classes_Objects;

public class ObjectDemo {
	int a;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 ObjectDemo  obj=new  ObjectDemo();
		System.out.println(  obj.a);

	}

}
