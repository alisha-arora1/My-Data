package classes_Objects;

import java.util.Scanner;

class Student
{
	private int rollNumber;
	private String name;
	private String[] courses=new String[4];
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String[] getCourses() {
		return courses;
	}
	public void setCourses(String[] courses) {
		this.courses = courses;
	}
	
}

public class Details {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int rollNumber,n;
		String name;
		 
		Student obj=new Student();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Student Roll Number:");
		rollNumber=sc.nextInt();
		System.out.println("Enter Student Name:");
		 name=sc.next();
		System.out.println("how many courses do you want to register? 3 or 4?");
		n=sc.nextInt();
		
		
	    System.out.println("enter the courses:");
	    String[] courses=new String[n];
		            for(int i=0;i<n;i++)
		        	 courses[i]=sc.next();
			       
		obj.setRollNumber(rollNumber);
		obj.setName(name);
		obj.setCourses(courses);
		System.out.println("Roll Number:"+obj.getRollNumber());
		System.out.println("Name:"+obj.getName());
		System.out.print("Courses:");
		for(int j=0;j<obj.getCourses().length;j++)
		{
			System.out.print(obj.getCourses()[j]+" ");
		}
	}

}
