package classes_Objects;

public class ObjectDemo2 {
   int i=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ObjectDemo2 one=new ObjectDemop2();
		

	}

}
