package classes_Objects;

public class DefaultValue {
   byte a;
    short b;
    int c;
    long d;
    float e;
    double g;
    char i;
    boolean h;
    
  
    
	public static void main(String[] args) {
		// TODO Auto-generated method stub
       DefaultValue one = new DefaultValue();
       System.out.print(one.a);
       System.out.print(one.b);
       System.out.print(one.c);
       System.out.print(one.d);
       System.out.print(one.e);
       System.out.print(one.g);
       System.out.print(one.i);     //we will get a space for character
       System.out.print(one.h);
       
	}

}
