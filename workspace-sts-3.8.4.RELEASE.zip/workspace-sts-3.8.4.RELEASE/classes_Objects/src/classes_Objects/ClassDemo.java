package classes_Objects;
class Employee
{
	
	private int employeeNumber;
	private String name;
	public int getEmployeeNumber() {
		return employeeNumber;
	}
	public void setEmployeeNumber(int employeeNumber) {
		this.employeeNumber = employeeNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}


public class ClassDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp=new Employee();
		emp.setEmployeeNumber(101);
		emp.setName("Sachin");
		System.out.println(emp.getEmployeeNumber());
		System.out.println(emp.getName());
        emp.
	}

}
