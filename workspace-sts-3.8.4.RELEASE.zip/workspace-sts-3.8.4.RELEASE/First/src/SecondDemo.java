import java.util.Scanner;

public class SecondDemo {
	public static void main(String args[]) {
		int choice;
		double a,b,c;
		Scanner sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter choice");
			System.out.println("1.addition");
			System.out.println("2.subtraction");
			System.out.println("3.product");
			System.out.println("4.division");
			System.out.println("5.exit");
			System.out.println("enter choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: System.out.println("enter value of a:");
			        a=sc.nextInt();
			        System.out.println("enter value of b:");
			        b=sc.nextInt();
			        c=a+b;
			        System.out.println("sum="+c);
			        break;
			case 2: System.out.println("enter value of a:");
	                a=sc.nextInt();
	                System.out.println("enter value of b:");
	                b=sc.nextInt();
	                c=a-b;
	                System.out.println("Difference="+c);
	                break;
			case 3: System.out.println("enter value of a:");
	                a=sc.nextInt();
	                System.out.println("enter value of b:");
	                b=sc.nextInt();
	                c=a*b;
	                System.out.println("product="+c);
	                break;
			case 4: System.out.println("enter value of a:");
	                a=sc.nextInt();
	                System.out.println("enter value of b:");
	                b=sc.nextInt();
	                c=a/b;
	                System.out.println("sum="+c);
	                break;
			case 5: System.exit(0);
			        
			}
		}
		
	}

}
