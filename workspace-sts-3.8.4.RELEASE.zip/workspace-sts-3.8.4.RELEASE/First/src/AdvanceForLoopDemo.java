import java.util.Scanner;

public class AdvanceForLoopDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] ary={1,2,3};
		for(int a: ary)
		{
			System.out.println(a);
			
		}

	}

}

