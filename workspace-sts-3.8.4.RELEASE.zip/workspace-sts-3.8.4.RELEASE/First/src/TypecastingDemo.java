import java.util.Scanner;

public class TypecastingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b;
		float c;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a:");
		a=sc.nextInt();
		System.out.println("enter b:");
		b=sc.nextInt();
		c=(float)a/b;
		System.out.println("c="+c);

	}

}
