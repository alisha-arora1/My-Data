public class Maths {
	
	public int fact(int num)
	{
		if(num==0)
			return 1;
		if(num==1)
			return 1;
		if(num<0)
			
			throw new IllegalArgumentException();
		if(num>1)
		{   int s=1;
			for(int i=2;i<=num;i++)
				s=s*i;
			return s;
		}
		return 1;
		
	}
	public boolean isEvenNumber(int number)
	{
        
        boolean result = false;
        if(number%2 == 0){
            result = true;
        }
        return result;
    }
}
