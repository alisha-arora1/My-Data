interface MyInterface
{
	int a=600;//public static final by default
	void show();//public abstract
}
class MyClass implements MyInterface
{
	public void show()
	{
		System.out.println(a);
		
	}
}
public class interfaceDemo2 {

	public static void main(String[] args) {
	    MyInterface m=new MyClass();
	    m.show();
	    

	}

}
