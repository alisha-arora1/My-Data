abstract class Bank{
	abstract int getRateOfInterest();
}
class SBI extends Bank{
	int getRateOfInterest()
	{
		return 7;
	}
}
class PNB extends Bank{
	int getRateOfInterest()
	{
		return 8;
	}
}
public class abstractDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bank b=new SBI();
		int interest=b.getRateOfInterest();
		System.out.println("rate of interest is:"+interest+"%");

	}

}
