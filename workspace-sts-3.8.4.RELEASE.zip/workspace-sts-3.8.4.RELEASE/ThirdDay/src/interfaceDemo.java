interface Bank{
	 int getRateOfInterest();
}
class SBI implements Bank{
	int getRateOfInterest()
	{
		return 7;
	}
}
class PNB implements Bank{
	int getRateOfInterest()
	{
		return 8;
	}
}
public class interfaceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bank b=new SBI();
		int interest=b.getRateOfInterest();
		System.out.println("rate of interest is:"+interest+"%");

	}

}