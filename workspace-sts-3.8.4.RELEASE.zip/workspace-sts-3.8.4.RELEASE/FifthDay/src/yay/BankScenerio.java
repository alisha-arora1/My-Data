package yay;

class InsufficientBalance extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
class MyClass
{
	void show(int balance) throws InsufficientBalance
	{
		if(balance<5000)
		{
			throw new InsufficientBalance()
;		}
		else
			System.out.println("account can be opened");
	}
}
public class BankScenerio {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClass m=new MyClass();
		try{
		m.show(8000);
		}catch(InsufficientBalance r)
		{
			System.out.println("Insufficient balace for opening the account");
		}
	}

}

