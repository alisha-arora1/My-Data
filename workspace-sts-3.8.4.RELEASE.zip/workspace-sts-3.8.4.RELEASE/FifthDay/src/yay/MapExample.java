package yay;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashMap<Integer,String> obj=new HashMap<>();
		
		
		
		obj.put(1, "one");
		
		obj.put(2, "two");
		obj.put(3, "three");
		//1
      System.out.println(obj);
      
      
      //2
      System.out.println("using keyset");
      Set s=obj.keySet();
      Iterator it=s.iterator();
      while(it.hasNext())
      {
    	  Integer key=(Integer)it.next();
    	  System.out.println(key);
    	  System.out.println(obj.get(key));
      }
      
      
      //3
      
      System.out.println("using entryset");
    
      
      Set su=obj.entrySet();
      Iterator i=su.iterator();
      while(i.hasNext()){
          Map.Entry m= (HashMap.Entry) i.next();
          System.out.println(""+m.getKey()+" "+ m.getValue());
      }
	}
}


