package yay;
class RangeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
class MyClas
{
	void show(int a) throws RangeException
	{
		if(a<10)
		{
			throw new RangeException()
;		}
	}
}
public class Inter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		MyClas m=new MyClas();
		try{
		m.show(2);
		}catch(RangeException r)
		{
			System.out.println("not a valid range number");
		}
	}

}
