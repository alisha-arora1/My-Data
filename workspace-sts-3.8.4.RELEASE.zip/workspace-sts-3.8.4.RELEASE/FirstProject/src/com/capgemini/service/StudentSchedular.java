package com.capgemini.service;
import com.capgemini.beans.Student;
public class StudentSchedular {

	private Student[] students = new Student[10];

	private int counterStudent;

	public String addStudent(int rollNumber,String name,int noOfCourses,String[] courses)

	{

			students[counterStudent++]=new Student(rollNumber,name,noOfCourses,courses);

		    return "Student added successfully";

	}

	public void showAllStudents()

	{

		for(int i=0;i<counterStudent;i++)

		{
			int x=i+1;
			
           System.out.println("student"+x+":");
			System.out.println("Roll number:"+students[i].getRollNumber());

			System.out.println("Name:"+students[i].getName());
			
			for(int j=0;j<students[i].getCourses().length;j++)
			{
				int t=j+1;
			System.out.println("course"+t+":"+students[i].getCourses()[j]);
			}
			System.out.println();
		}

	}
	public void showByRollNo(int rno)
	{
		int flag=0;
		for(int i=0;i<counterStudent;i++)

		{
           
			if(students[i].getRollNumber()==rno)
			{
				flag++;
			 System.out.println(students[i].getName());
			}
		  
		}
		 if(flag==0)
		 System.out.println("roll number not found!");
	}
	public void showByCourse(String courseName)
	{
		int flag=0;
		for(int i=0;i<counterStudent;i++)

		{
			for(int j=0;j<students[i].getCourses().length;j++)
			{
			 if((students[i].getCourses()[j]).equals(courseName)==true)
				 { flag++;
				 System.out.println("Roll number:"+students[i].getRollNumber());

					System.out.print("Name:"+students[i].getName());
					System.out.println();
			     }
			}
			
			if(flag==0)
				System.out.println("course not found!");
	
		}
	}
	 public boolean isRollNumberPresent(int rollNumber)
		{
			for(int i=0;i<counterStudent;i++)

			{
	           
				if(students[i].getRollNumber()==rollNumber)
			    return true;
			}
			return false;
			
		}
		
}
