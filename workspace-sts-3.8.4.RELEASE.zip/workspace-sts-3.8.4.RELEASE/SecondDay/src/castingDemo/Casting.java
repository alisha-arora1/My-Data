package castingDemo;
class Vehicle{}
class Car extends Vehicle{
	
}
class Bus extends Vehicle{
	
}

public class Casting {
	

	public static void main(String[] args) {
		
		Car c=new Car();
		Vehicle v=c;
		Car c2=(Car)v;
		//Bus b=(bus)v;
		
	}

}
