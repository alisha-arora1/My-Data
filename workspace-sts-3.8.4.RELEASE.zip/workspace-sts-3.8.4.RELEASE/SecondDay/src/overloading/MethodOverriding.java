package overloading;
class Parent
{   
	Parent(){
		super();
		System.out.println("parent superex");

	}
 	void func()
	{
		System.out.println("i am parent");
	}
}

class MethodOverriding extends Parent
{
	MethodOverriding(){
		super();
		System.out.println("child super");

	}
	void func()
	{
		System.out.println("i am child");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
           MethodOverriding m= new MethodOverriding();
           m.func();
	}

}
