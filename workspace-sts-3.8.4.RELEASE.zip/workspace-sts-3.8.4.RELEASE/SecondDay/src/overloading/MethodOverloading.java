package overloading;

public class MethodOverloading {
	
   void one()
   {
	   System.out.println("one");
   }
   void one(int a,int b)
   {
	   int c=a+b;
	   System.out.println("two "+c);
   }
   void one(double x,int y)
   {
	   double z=x+y;
	   System.out.println("three "+z);
	   
   }

	public static void main(String[] args) {
		MethodOverloading m=new MethodOverloading();
		m.one();
		m.one(2,3);
		m.one(5.5,4);

	}

}
