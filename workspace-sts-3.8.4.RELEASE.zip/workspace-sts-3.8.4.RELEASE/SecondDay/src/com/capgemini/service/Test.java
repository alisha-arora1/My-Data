package com.capgemini.service;

import java.util.Scanner;

import com.capgemini.beans.Employee;

public class Test {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		
		
		Employee[] emps=new Employee[3];
		
		for(int k=0;k<3;k++)
		{
		 emps[k]=new Employee();
		}
		for(int i=0;i<3;i++)
		{
		  System.out.println("Enter the employee number:");
		  emps[i].setEmployeeNumber(sc.nextInt());
		  System.out.println("Enter the employee name:");
		  emps[i].setName(sc.next());
		}
		
		
		for(int j=0;j<3;j++)
		{
		  System.out.print("employee number:");
		  System.out.println(emps[j].getEmployeeNumber());
		  System.out.print("employee name:");
		  System.out.println(emps[j].getName());
		}
		
		
		
		
		

	}

}
